const express = require('express');
const router = express.Router();
const { getAllEvents, createEvent, getEvent, updateEvent, deleteEvent } = require('../controllers/eventController');

router.get('/', getAllEvents);
router.post('/', createEvent);
router.get('/:id', getEvent);
router.put('/:id', updateEvent);
router.delete('/:id', deleteEvent);

module.exports = router;