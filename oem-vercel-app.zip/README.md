# OEM Vercel App

This project packages your original backend (copied under `/api/backend`) and a Vite React frontend (in `/frontend`) for seamless deployment to **Vercel**.

## How it works
- `/api/index.js` is a serverless function (using `serverless-http`) that mounts your Express route files (from `/api/backend/routes`). 
- The frontend lives in `/frontend` and is built by Vercel using `frontend/package.json` and served as static files.

## Local testing with Vercel CLI
1. Install Vercel CLI:
   ```bash
   npm i -g vercel
   ```
2. Install dependencies:
   ```bash
   npm install
   cd frontend && npm install
   ```
3. Run locally:
   ```bash
   vercel dev
   ```

## Deploy
1. Push this repo to GitHub.
2. In Vercel, create a new project and import the repo.
3. Vercel will use `vercel.json` to build the frontend and the API.
4. Add environment variables (e.g., `MONGO_URI`, `JWT_SECRET`) in Vercel Project Settings → Environment Variables.

## Notes
- If your route modules expect additional app-level middleware (session, passport, etc.), copy that setup into `api/index.js` before mounting routes.
- The function mounts detected route files as shown in `route-analysis.json`.
