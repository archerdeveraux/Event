document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('register-form');
    const loginForm = document.getElementById('login-form');
    const eventsSection = document.getElementById('events-section');
    const eventsList = document.getElementById('events-list');
    const refreshEventsBtn = document.getElementById('refresh-events');

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('reg-name').value;
        const email = document.getElementById('reg-email').value;
        const password = document.getElementById('reg-password').value;
        const role = document.getElementById('reg-role').value;

        const response = await fetch('/api/users/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password, role })
        });

        const result = await response.json();
        alert(result.message);
    });

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;

        const response = await fetch('/api/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const result = await response.json();
        if (response.ok) {
            document.getElementById('auth-section').style.display = 'none';
            eventsSection.style.display = 'block';
            loadEvents();
        } else {
            alert(result.message);
        }
    });

    refreshEventsBtn.addEventListener('click', loadEvents);

    async function loadEvents() {
        const response = await fetch('/api/events');
        const events = await response.json();
        eventsList.innerHTML = '';
        events.forEach(event => {
            const eventDiv = document.createElement('div');
            eventDiv.className = 'event';
            eventDiv.innerHTML = `
                <h3>${event.title}</h3>
                <p>${event.description}</p>
                <p>Date: ${new Date(event.date).toLocaleDateString()}</p>
                <p>Location: ${event.location}</p>
                <p>Seats: ${event.seats}</p>
                <button class="book-btn" data-event-id="${event._id}">Book</button>
            `;
            eventsList.appendChild(eventDiv);
        });

        document.querySelectorAll('.book-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const eventId = e.target.dataset.eventId;
                const response = await fetch('/api/bookings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ event_id: eventId })
                });
                const result = await response.json();
                alert(result.message);
                if (response.ok) loadEvents();
            });
        });
    }
});