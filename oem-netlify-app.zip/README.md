# OEM Netlify App

This packages frontend + backend (as Netlify Function) for easy deploy.

Detected mounts:
{
  "/api/booking": "routes/bookingRoutes.js",
  "/api/event": "routes/eventRoutes.js",
  "/api/user": "routes/userRoutes.js"
}

Steps:
1. npm install
2. cd frontend && npm install
3. netlify dev
4. git init, push, then on Netlify set build command: npm run build and publish: frontend/dist

Set env vars (MONGODB_URI) in Netlify.
