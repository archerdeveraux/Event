# EventEase (RishiFile Edition)

## 🚀 Overview
Full-stack Event Management system using:
- **Backend:** Express + MongoDB + JWT Auth
- **Frontend:** React (Vite) + TailwindCSS
- **Deployment:** Vercel (frontend), MongoDB Atlas (database)

---

## 🧩 Local Setup

### 1. Backend
```bash
cd oem
cp .env.example .env
npm install
npm start
```

### 2. Frontend
```bash
cd frontend_vite
npm install
npm run dev
```

Your app will run on:
- Backend → http://localhost:5000
- Frontend → http://localhost:5173

---

## 🌐 MongoDB Atlas Setup
1. Go to [https://cloud.mongodb.com](https://cloud.mongodb.com)
2. Create a free cluster.
3. Create a database named **eventdb**.
4. Whitelist your IP or use `0.0.0.0/0`.
5. Create a database user with a secure password.
6. Copy the connection string:
   ```
   mongodb+srv://<username>:<password>@cluster0.xxxxxx.mongodb.net/eventdb
   ```
7. Replace it in `.env` under `MONGO_URI`.

---

## 🧰 Environment Variables (`.env.example`)
```env
MONGO_URI=mongodb+srv://<username>:<password>@cluster0.xxxxxx.mongodb.net/eventdb
JWT_SECRET=your_jwt_secret_here
PORT=5000
```

---

## ☁️ Vercel Deployment

### Automatic setup (recommended)
`.vercel.json` in root ensures correct build:
```json
{
  "version": 2,
  "projects": [
    {
      "src": "frontend_vite/",
      "use": "@vercel/static-build",
      "config": { "distDir": "frontend_vite/dist" }
    }
  ],
  "routes": [
    { "src": "/(.*)", "dest": "frontend_vite/dist/index.html" }
  ]
}
```

Steps:
1. Push your repo to GitHub.
2. Go to [https://vercel.com/new](https://vercel.com/new).
3. Import the repo.
4. Click *Deploy* — done!

---

## ❤️ Author
Created for Rishi — full-stack event management solution ready for deployment.
