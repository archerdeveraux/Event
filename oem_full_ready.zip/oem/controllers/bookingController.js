const Booking = require('../models/Booking');
const Event = require('../models/Event');

exports.bookEvent = async (req, res) => {
  try {
    if (!req.session.userId) return res.status(401).json({ message: 'Not logged in' });
    const { event_id } = req.body;
    const event = await Event.findById(event_id);
    if (!event || event.seats <= 0) return res.status(400).json({ message: 'No seats available' });
    const ticket_id = `TKT${event_id}${req.session.userId}`;
    const booking = new Booking({ user_id: req.session.userId, event_id, ticket_id });
    await booking.save();
    event.seats--;
    await event.save();
    res.json({ message: 'Booking confirmed', ticket_id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};