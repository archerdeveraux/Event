import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';

export default function Navbar({ onNavigate }) {
  const { user, logout } = useContext(AuthContext);
  return (
    <nav className="flex items-center justify-between bg-white p-4 rounded shadow mb-6">
      <div className="flex items-center gap-4">
        <div className="text-xl font-bold">EventEase</div>
        <button className="text-sm text-gray-600" onClick={()=>onNavigate('events')}>Events</button>
        <button className="text-sm text-gray-600" onClick={()=>onNavigate('bookings')}>Bookings</button>
      </div>
      <div className="flex items-center gap-3">
        {user ? (
          <>
            <div className="text-sm text-gray-700">Hi, <strong>{user.name || user.email}</strong></div>
            <button className="btn" onClick={()=>{ logout(); onNavigate('login'); }}>Logout</button>
          </>
        ) : (
          <>
            <button className="text-sm text-indigo-600" onClick={()=>onNavigate('login')}>Login</button>
            <button className="text-sm text-indigo-600" onClick={()=>onNavigate('register')}>Register</button>
          </>
        )}
      </div>
    </nav>
  )
}
