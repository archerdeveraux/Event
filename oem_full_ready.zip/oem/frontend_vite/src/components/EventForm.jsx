import React, { useState } from 'react'

export default function EventForm({ onCreate }) {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [location, setLocation] = useState('')
  const [date, setDate] = useState('')
  const [capacity, setCapacity] = useState(50)

  async function submit(e) {
    e.preventDefault()
    await onCreate({ title, description, location, date, capacity })
    setTitle(''); setDescription(''); setLocation(''); setDate(''); setCapacity(50)
  }

  return (
    <div className="bg-white p-4 rounded shadow">
      <h3 className="font-semibold mb-2">Create Event</h3>
      <form onSubmit={submit} className="space-y-2">
        <input className="w-full border p-2 rounded" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title" required />
        <textarea className="w-full border p-2 rounded" value={description} onChange={e=>setDescription(e.target.value)} placeholder="Description" />
        <input className="w-full border p-2 rounded" value={location} onChange={e=>setLocation(e.target.value)} placeholder="Location" />
        <input className="w-full border p-2 rounded" value={date} onChange={e=>setDate(e.target.value)} placeholder="YYYY-MM-DDTHH:mm" />
        <input className="w-full border p-2 rounded" value={capacity} type="number" onChange={e=>setCapacity(e.target.value)} />
        <div>
          <button className="btn" type="submit">Create</button>
        </div>
      </form>
    </div>
  )
}
