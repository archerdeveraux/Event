import React from 'react'

export default function EventCard({ event, onBook }) {
  return (
    <div className="bg-white p-4 rounded shadow mb-4">
      <h3 className="text-lg font-semibold">{event.title}</h3>
      <p className="text-gray-600">{event.description}</p>
      <div className="mt-2 text-sm text-gray-500">{event.location} • {event.date ? new Date(event.date).toLocaleString() : ''}</div>
      <div className="mt-3">
        <button className="btn" onClick={()=>onBook(event._id||event.id)}>Book</button>
      </div>
    </div>
  )
}
