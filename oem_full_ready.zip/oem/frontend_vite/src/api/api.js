// Central API layer - configured for local backend
const apiBase = 'http://localhost:5000';

async function check(res) {
  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text } }
  if (!res.ok) {
    const e = new Error(data?.message || 'Request failed');
    e.body = data;
    throw e;
  }
  return data;
}

export function register(payload) {
  return fetch(`${apiBase}/api/users/register`, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  }).then(check);
}

export function login({ email, password }) {
  return fetch(`${apiBase}/api/users/login`, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ email, password })
  }).then(check);
}

export function fetchEvents() {
  return fetch(`${apiBase}/api/events`, { credentials: 'include' }).then(check);
}

export function createEvent(token, payload) {
  return fetch(`${apiBase}/api/events`, {
    method: 'POST',
    headers: { 'Content-Type':'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload)
  }).then(check);
}

export function bookEvent(token, event_id) {
  return fetch(`${apiBase}/api/bookings`, {
    method: 'POST',
    headers: { 'Content-Type':'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ event_id })
  }).then(check);
}

export function fetchBookings(token) {
  return fetch(`${apiBase}/api/bookings`, {
    headers: { Authorization: `Bearer ${token}` }
  }).then(check);
}
