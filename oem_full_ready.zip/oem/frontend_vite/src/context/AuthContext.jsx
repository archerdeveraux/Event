import React, { createContext, useState, useEffect } from 'react';
import * as api from '../api/api';

export const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('oem_user')) } catch { return null }
  });
  const [token, setToken] = useState(() => localStorage.getItem('oem_token'));
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user && token) {
      localStorage.setItem('oem_user', JSON.stringify(user));
      localStorage.setItem('oem_token', token);
    } else {
      localStorage.removeItem('oem_user');
      localStorage.removeItem('oem_token');
    }
  }, [user, token]);

  async function login(email, password) {
    setLoading(true);
    try {
      const res = await api.login({ email, password });
      // assume backend returns { user, token } or similar
      const u = res.user || res.userData || res.userInfo || res;
      const t = res.token || res.accessToken || res.jwt;
      if (!t) throw new Error('No token returned from backend.');
      setUser(u);
      setToken(t);
      return { ok: true };
    } catch (err) {
      console.error('login error', err);
      return { ok: false, message: err?.body?.message || err.message };
    } finally {
      setLoading(false);
    }
  }

  async function register(payload) {
    setLoading(true);
    try {
      const res = await api.register(payload);
      return { ok: true, data: res };
    } catch (err) {
      return { ok: false, message: err?.body?.message || err.message };
    } finally {
      setLoading(false);
    }
  }

  function logout() {
    setUser(null);
    setToken(null);
    // optionally notify backend if using sessions
  }

  return (
    <AuthContext.Provider value={{ user, token, loading, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
}
