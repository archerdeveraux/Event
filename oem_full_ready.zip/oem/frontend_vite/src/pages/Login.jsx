import React, { useState, useContext } from 'react'
import { AuthContext } from '../context/AuthContext'

export default function LoginPage({ onNavigate }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState('')
  const { login } = useContext(AuthContext)

  async function submit(e) {
    e.preventDefault()
    setErr('')
    setLoading(true)
    try {
      const res = await login(email, password)
      if (!res.ok) {
        setErr(res.message || 'Login failed')
      } else {
        onNavigate('events')
      }
    } catch (error) {
      setErr(error?.body?.message || error.message || 'Login failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-semibold mb-4">Login</h2>
      <form onSubmit={submit} className="space-y-3">
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" className="w-full border p-2 rounded" required />
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" className="w-full border p-2 rounded" required />
        {err && <div className="text-red-600">{err}</div>}
        <div className="flex items-center justify-between">
          <button className="btn" disabled={loading}>{loading ? 'Signing...' : 'Sign in'}</button>
          <button type="button" className="text-sm text-indigo-600" onClick={()=>onNavigate('register')}>Create account</button>
        </div>
      </form>
    </div>
  )
}
