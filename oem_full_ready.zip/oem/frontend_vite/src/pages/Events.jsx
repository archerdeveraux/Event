import React, { useEffect, useState } from 'react'
import * as api from '../api/api'
import EventCard from '../components/EventCard'
import EventForm from '../components/EventForm'

export default function EventsPage() {
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(false)
  const [user, setUser] = useState(()=> {
    try { return JSON.parse(localStorage.getItem('oem_user')) } catch { return null }
  })

  async function load() {
    setLoading(true)
    try {
      const res = await api.fetchEvents()
      setEvents(res.events || res)
    } catch (err) {
      console.error(err)
    } finally { setLoading(false) }
  }

  useEffect(()=> { load() }, [])

  async function handleBook(id) {
    const token = localStorage.getItem('oem_token')
    if (!token) return alert('Please login to book.')
    try {
      await api.bookEvent(token, id)
      alert('Booked!')
      load()
    } catch (err) {
      alert(err?.body?.message || 'Booking failed')
    }
  }

  async function handleCreate(payload) {
    const token = localStorage.getItem('oem_token')
    if (!token) return alert('Must be logged in as organizer.')
    try {
      await api.createEvent(token, payload)
      load()
    } catch (err) {
      alert(err?.body?.message || 'Create failed')
    }
  }

  return (
    <div className="grid md:grid-cols-3 gap-6">
      <div className="md:col-span-2">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-semibold">Events</h2>
          <button className="btn" onClick={load}>Refresh</button>
        </div>
        {loading ? <div>Loading...</div> : (
          events.length === 0 ? <div className="text-gray-500">No events</div> :
          events.map(ev => <EventCard key={ev._id||ev.id} event={ev} onBook={handleBook} />)
        )}
      </div>
      <aside>
        {user?.role === 'organizer' ? <EventForm onCreate={handleCreate} /> : (
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold">Bookings</h3>
            <p className="text-sm text-gray-600">Go to bookings page after logging in.</p>
          </div>
        )}
      </aside>
    </div>
  )
}
