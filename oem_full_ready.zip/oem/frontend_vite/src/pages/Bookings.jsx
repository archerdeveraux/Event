import React, { useEffect, useState, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import * as api from '../api/api';

export default function BookingsPage() {
  const { token, user } = useContext(AuthContext);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(()=> {
    async function load() {
      if (!token) return;
      setLoading(true);
      try {
        const res = await api.fetchBookings(token);
        setBookings(res.bookings || res);
      } catch (err) {
        console.error(err);
        setBookings([]);
      } finally { setLoading(false) }
    }
    load();
  }, [token]);

  if (!user) return <div className="bg-white p-6 rounded shadow">Please login to view bookings.</div>

  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-xl font-semibold mb-3">Your Bookings</h2>
      {loading ? <div>Loading...</div> : (
        bookings.length === 0 ? <div className="text-gray-500">No bookings yet.</div> :
        <ul className="space-y-3">
          {bookings.map(b => (
            <li key={b._id || b.id} className="p-3 border rounded">
              <div className="font-semibold">{b.event?.title || b.title}</div>
              <div className="text-sm text-gray-500">{b.event?.date ? new Date(b.event.date).toLocaleString() : b.createdAt ? new Date(b.createdAt).toLocaleString() : ''}</div>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
