import React, { useState, useContext } from 'react'
import { AuthContext } from '../context/AuthContext'

export default function RegisterPage({ onNavigate }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState('user')
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState('')
  const { register } = useContext(AuthContext)

  async function submit(e) {
    e.preventDefault()
    setErr('')
    setLoading(true)
    try {
      const res = await register({ name, email, password, role })
      if (!res.ok) {
        setErr(res.message || 'Registration failed')
      } else {
        onNavigate('login')
      }
    } catch (error) {
      setErr(error?.body?.message || error.message || 'Registration failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-semibold mb-4">Register</h2>
      <form onSubmit={submit} className="space-y-3">
        <input value={name} onChange={e=>setName(e.target.value)} placeholder="Name" className="w-full border p-2 rounded" required />
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" className="w-full border p-2 rounded" required />
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" className="w-full border p-2 rounded" required />
        <select value={role} onChange={e=>setRole(e.target.value)} className="w-full border p-2 rounded">
          <option value="user">User</option>
          <option value="organizer">Organizer</option>
        </select>
        {err && <div className="text-red-600">{err}</div>}
        <div className="flex items-center justify-between">
          <button className="btn" disabled={loading}>{loading ? 'Creating...' : 'Create account'}</button>
          <button type="button" className="text-sm text-indigo-600" onClick={()=>onNavigate('login')}>Have an account?</button>
        </div>
      </form>
    </div>
  )
}
