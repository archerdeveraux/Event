import React, { useState } from 'react'
import { AuthProvider } from './context/AuthContext'
import EventsPage from './pages/Events'
import LoginPage from './pages/Login'
import RegisterPage from './pages/Register'
import BookingsPage from './pages/Bookings'
import Navbar from './components/Navbar'

function AppRouter({ route, setRoute }) {
  if (route === 'login') return <LoginPage onNavigate={setRoute} />
  if (route === 'register') return <RegisterPage onNavigate={setRoute} />
  if (route === 'bookings') return <BookingsPage />
  return <EventsPage />
}

export default function App() {
  const [route, setRoute] = useState('events')
  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-5xl mx-auto p-6">
          <Navbar onNavigate={setRoute} />
          <AppRouter route={route} setRoute={setRoute} />
        </div>
      </div>
    </AuthProvider>
  )
}
