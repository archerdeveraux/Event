# OEM Frontend (Vite + React + Tailwind)

This frontend expects your backend API to be running at `http://localhost:5000`.

## Install

```bash
cd frontend_vite
npm install
npm run dev
```

## Notes

- The API base is set in `src/api/api.js`.
- Authentication stores token in `localStorage` key `oem_token` and user in `oem_user`.
- If your backend runs on a different port or host, update `apiBase` in `src/api/api.js`.
