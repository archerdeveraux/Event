import React, {useEffect, useState} from 'react'
import api from '../api'

export default function Profile(){
  const [profile, setProfile] = useState(null)

  useEffect(()=>{
    api.getProfile().then(d=> setProfile(d.user || d)).catch(()=>{})
  },[])

  if (!profile) return <p>Not logged in or loading...</p>

  return (
    <div className="profile">
      <h2>Profile</h2>
      <p><strong>Name:</strong> {profile.name}</p>
      <p><strong>Email:</strong> {profile.email}</p>
      <p><strong>Role:</strong> {profile.role}</p>
    </div>
  )
}
