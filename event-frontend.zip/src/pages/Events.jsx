import React, {useEffect, useState} from 'react'
import { Link } from 'react-router-dom'
import api from '../api'

export default function Events(){
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  async function load(){
    setLoading(true)
    try{
      const data = await api.getEvents()
      setEvents(data.events || data || [])
    }catch(e){
      setError('Failed to load events')
    }finally{ setLoading(false) }
  }

  useEffect(()=>{ load() },[])

  if (loading) return <p>Loading events...</p>
  if (error) return <p>{error}</p>

  return (
    <div className="events-page">
      <h2>Available Events</h2>
      <div className="events-grid">
        {events.map(ev=> (
          <article key={ev._id || ev.id} className="card">
            <h3>{ev.title}</h3>
            <p>{ev.description?.slice(0,140)}</p>
            <p><strong>Date:</strong> {ev.date}</p>
            <Link to={`/events/${ev._id || ev.id}`} className="btn">View</Link>
          </article>
        ))}
      </div>
    </div>
  )
}
