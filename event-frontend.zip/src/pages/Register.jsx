import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../api'

export default function Register(){
  const [name,setName]=useState('')
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [role,setRole]=useState('attendee')
  const [msg,setMsg]=useState(null)
  const nav = useNavigate()

  async function submit(e){
    e.preventDefault()
    const res = await api.register({ name, email, password, role })
    setMsg(res.message || JSON.stringify(res))
    if (res.success) setTimeout(()=>nav('/login'), 600)
  }

  return (
    <div className="auth">
      <h2>Register</h2>
      <form onSubmit={submit}>
        <label>Name<input value={name} onChange={e=>setName(e.target.value)} required /></label>
        <label>Email<input value={email} onChange={e=>setEmail(e.target.value)} required /></label>
        <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required /></label>
        <label>Role
          <select value={role} onChange={e=>setRole(e.target.value)}>
            <option value="attendee">Attendee</option>
            <option value="organizer">Organizer</option>
          </select>
        </label>
        <button className="btn">Register</button>
      </form>
      {msg && <p className="msg">{msg}</p>}
    </div>
  )
}
