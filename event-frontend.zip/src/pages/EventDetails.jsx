import React, {useEffect, useState} from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import api from '../api'

export default function EventDetails(){
  const { id } = useParams()
  const [event, setEvent] = useState(null)
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState(null)
  const nav = useNavigate()

  useEffect(()=>{
    let mounted = true
    api.getEvent(id).then(d=> { if (mounted) setEvent(d.event || d) }).catch(()=>{}).finally(()=>{ if (mounted) setLoading(false) })
    return ()=> mounted=false
  },[id])

  async function handleBook(){
    const res = await api.bookEvent(id)
    setMessage(res.message || JSON.stringify(res))
    if (res.success || res.message?.toLowerCase().includes('booked')) setTimeout(()=>nav('/'),800)
  }

  if (loading) return <p>Loading...</p>
  if (!event) return <p>Event not found.</p>

  return (
    <div className="event-detail">
      <h2>{event.title}</h2>
      <p>{event.description}</p>
      <p><strong>Date:</strong> {event.date}</p>
      <button className="btn" onClick={handleBook}>Book this event</button>
      {message && <p className="msg">{message}</p>}
    </div>
  )
}
