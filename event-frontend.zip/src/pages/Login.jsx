import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../api'

export default function Login(){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [error,setError]=useState(null)
  const nav = useNavigate()

  async function submit(e){
    e.preventDefault()
    const res = await api.login({ email, password })
    if (res && res.token){
      nav('/')
    } else {
      setError(res.message || 'Login failed')
    }
  }

  return (
    <div className="auth">
      <h2>Login</h2>
      <form onSubmit={submit}>
        <label>Email<input value={email} onChange={e=>setEmail(e.target.value)} required /></label>
        <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required /></label>
        <button className="btn">Login</button>
      </form>
      {error && <p className="error">{error}</p>}
    </div>
  )
}
