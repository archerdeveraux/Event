import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Events from './pages/Events'
import Login from './pages/Login'
import Register from './pages/Register'
import EventDetails from './pages/EventDetails'
import Profile from './pages/Profile'

export default function App(){
  return (
    <div className="app">
      <header>
        <h1><Link to="/">Event Manager</Link></h1>
        <nav>
          <Link to="/">Events</Link>
          <Link to="/profile">Profile</Link>
        </nav>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<Events />} />
          <Route path="/events/:id" element={<EventDetails />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </main>
      <footer>Built for deployment to Vercel</footer>
    </div>
  )
}
