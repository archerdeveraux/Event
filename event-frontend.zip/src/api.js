const api = {
  async getEvents(){
    const res = await fetch('/api/events');
    return res.json();
  },
  async getEvent(id){
    const res = await fetch(`/api/events/${id}`);
    return res.json();
  },
  async register(user){
    const res = await fetch('/api/users/register', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(user)
    });
    return res.json();
  },
  async login(creds){
    const res = await fetch('/api/users/login', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(creds)
    });
    if (res.ok){
      const data = await res.json();
      localStorage.setItem('token', data.token || '');
      return data;
    } else {
      return res.json();
    }
  },
  async bookEvent(eventId){
    const token = localStorage.getItem('token');
    const res = await fetch('/api/bookings', {
      method: 'POST',
      headers: {'Content-Type':'application/json', 'Authorization': token ? `Bearer ${token}` : ''},
      body: JSON.stringify({ event_id: eventId })
    });
    return res.json();
  },
  async getProfile(){
    const token = localStorage.getItem('token');
    const res = await fetch('/api/users/profile', {
      headers: { 'Authorization': token ? `Bearer ${token}` : '' }
    });
    return res.json();
  }
}

export default api
