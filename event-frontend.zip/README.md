# Event Manager Frontend

This React + Vite frontend talks to your existing backend at `/api/*` endpoints:
- `GET /api/events`
- `GET /api/events/:id`
- `POST /api/users/register`
- `POST /api/users/login`
- `POST /api/bookings`

## Run locally

1. Install dependencies: `npm install`
2. Start dev server: `npm run dev`
3. The dev server runs at `http://localhost:5173` by default.

If your backend runs on a different port, configure a proxy in `vite.config.js` or run both via a reverse proxy.

## Deploy to Vercel

1. Push this project to a Git provider (GitHub/GitLab).
2. In Vercel, create a new project and link the repo.
3. Set the build command: `npm run build` and output directory: `dist`.
4. Set any environment variables if your backend is remote (e.g. `API_BASE_URL`) and adjust fetch calls accordingly.
5. Optionally, use Vercel rewrites if your backend is hosted on the same domain, or configure CORS on the backend.

## Notes for MetLife (internal)

- If deploying inside an internal MetLife environment, ensure the frontend's domain is allowed by backend CORS settings and update `fetch` base URLs to point to the internal API host.
- Vercel may not be usable internally; consult your MetLife DevOps for an internal deployment target and CI/CD steps.

